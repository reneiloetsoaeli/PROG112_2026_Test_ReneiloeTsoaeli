package com.mycompany.consolesales;

/**
 * Contract for a console sales record.
 * NOTE: method names are a best guess - match them to your paper's interface.
 */
public interface IConsole {

    String getConsoleType();   // PS5, XBOX or SWITCH
    String getStoreName();     // store the sales belong to
    int getTotalSales();       // total sales amount

    // Builds the formatted sales report text
    String generateReport();
}
