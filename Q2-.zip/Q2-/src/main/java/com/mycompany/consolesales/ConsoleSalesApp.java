package com.mycompany.consolesales;

import java.util.Scanner;

public class ConsoleSalesApp {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        // Single-dimensional array holding the console types
        String[] consoleTypes = {"PS5", "XBOX", "SWITCH"};

        // ---- Display the menu ----
        System.out.println("Select the console type");
        for (int i = 0; i < consoleTypes.length; i++) {
            System.out.println(" " + (i + 1) + ") " + consoleTypes[i]);
        }
        System.out.println();

        // ---- Read and validate the menu choice (must be 1 to 3) ----
        int choice = input.nextInt();
        while (choice < 1 || choice > consoleTypes.length) {
            System.out.println("Invalid choice. Enter 1 to " + consoleTypes.length + ":");
            choice = input.nextInt();
        }
        input.nextLine(); // clear the leftover new line after nextInt()

        String consoleType = consoleTypes[choice - 1]; // menu is 1-based, array is 0-based

        // ---- Read the store name and sales ----
        System.out.print("Enter the store: ");
        String storeName = input.nextLine();

        System.out.print("Enter the total sales of " + consoleType
                + " consoles for " + storeName + ": ");
        int totalSales = input.nextInt();

        // ---- Create the object and print the report ----
        Console console = new Console(consoleType, storeName, totalSales);
        System.out.println();
        System.out.println(console.generateReport());

        input.close();
    }
}
