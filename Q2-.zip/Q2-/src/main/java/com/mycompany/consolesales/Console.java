package com.mycompany.consolesales;


public class Console implements IConsole {

    // Variables (private = encapsulation)
    private String consoleType;
    private String storeName;
    private int totalSales;

    // Constructor receives the values needed to initialise the object
    public Console(String consoleType, String storeName, int totalSales) {
        this.consoleType = consoleType;
        this.storeName = storeName;
        this.totalSales = totalSales;
    }

    @Override
    public String getConsoleType() {
        return consoleType;
    }

    @Override
    public String getStoreName() {
        return storeName;
    }

    @Override
    public int getTotalSales() {
        return totalSales;
    }

    @Override
    public String generateReport() {
        return "CONSOLE SALES REPORT\n"
             + "********************\n"
             + "CONSOLE TYPE: " + consoleType + "\n"
             + "STORE: " + storeName + "\n"
             + "TOTAL SALES: " + totalSales;
    }
}
