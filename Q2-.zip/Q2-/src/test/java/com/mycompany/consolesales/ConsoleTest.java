package com.mycompany.consolesales;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class ConsoleTest {

    @Test
    public void GenerateReport_ReturnsExpectedReport() {
        // Arrange
        Console console = new Console("PS5", "Number 1 Electronics Store", 500);
        String expected = "CONSOLE SALES REPORT\n"
                + "********************\n"
                + "CONSOLE TYPE: PS5\n"
                + "STORE: Number 1 Electronics Store\n"
                + "TOTAL SALES: 500";

        // Act
        String actual = console.generateReport();

        // Assert
        assertEquals(expected, actual);
    }
}
